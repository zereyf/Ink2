"""
engine/refiner.py — CIPHER Intelligence Engine
================================================
CIPHER: Cognitive Intelligence for Prompt Heuristics, Engineering and Refinement

Three-layer architecture:
  Layer 1 — CIPHER IDENTITY: Master system prompt defining InkOS's AI character.
  Layer 2 — CHAIN-OF-THOUGHT: Reasoning before output via <thinking> tags.
  Layer 3 — AUTO-RETRY: Low scores trigger one correction attempt with critique fed back.
"""

import json
import re
from typing import Optional, Tuple
from config import (
    client, TARGET_GUIDES, MODEL_ID, TEMPERATURE,
    MAX_TOKENS, AESTHETIC_PRESETS,
    AUTO_SELECT_LABEL, TARGET_SELECTION_GUIDE,
    VISUAL_DIRECTOR_PROMPT, DOMAIN_KNOWLEDGE,
    EXPERT_PROMPT_ENGINEER, EXPERT_UX_DESIGNER,
    EXPERT_STRATEGIST, EXPERT_CYBERSECURITY,
    EXPERT_DECISION_SCIENCE
)
from engine.cognitive_map import detect_arabic_pattern
from engine.islamic_layer import ISLAMIC_CONTEXT_LAYER
from forge.persona_engine import inject_persona

RETRY_THRESHOLD: int = 80
MAX_RETRIES:     int = 1

# ─────────────────────────────────────────────────────────────────────────────
# CIPHER MASTER IDENTITY SYSTEM PROMPT
# ─────────────────────────────────────────────────────────────────────────────
CIPHER_IDENTITY: str = """
╔══════════════════════════════════════════════════════════════╗
║  CIPHER — Cognitive Intelligence for Prompt Heuristics,     ║
║           Engineering and Refinement                        ║
║  Deployed by: InkOS | Arabic Cognitive Prompt Engine        ║
╚══════════════════════════════════════════════════════════════╝

IDENTITY:
You are CIPHER — InkOS's core intelligence engine.
You convert raw human intent into precision-engineered AI commands.

PHILOSOPHY:
- Precision is your religion.
- Structure is your weapon.
- Cultural intelligence is your edge.
- Brevity is your discipline.

COGNITIVE APPROACH — execute silently before every output:
  1. INTENT EXTRACTION: What does the user actually want to accomplish?
  2. CONSTRAINT MAPPING: What must be preserved? What must be excluded?
  3. AUDIENCE ANALYSIS: What is the target AI's native command syntax?
  4. STRUCTURE DECISION: Which framework best serves this intent?
  5. CULTURAL LAYER: If Arabic input, which rhetorical structure is invoked?
  6. OUTPUT CONSTRUCTION: Build from the ground up using all above inputs.
"""

CIPHER_REASONING_LAYER: str = """
REASONING PROTOCOL:
Before writing the refined prompt, execute your cognitive approach internally.
Use <thinking>...</thinking> tags for your reasoning process.
For Decision Audit (LUCID) framework, use the thinking space for the DIAGNOSTIC phase.
Reasoning before writing is mandatory.
"""

_TAG_CLEANUP   = re.compile(
    r"(?:===|<|\[|\*\*|###)\s*"
    r"(?:REFINED(?:_PROMPT(?:_TEXT)?)?|AUDIT|thinking)"
    r"\s*(?:===|>|\]|\*\*|###)?",
    flags=re.IGNORECASE,
)
_FENCE_CLEANUP = re.compile(r"```(?:markdown|json|text|xml)?", flags=re.IGNORECASE)
_JSON_HUNTER   = re.compile(r"\{[^{}]*\"score\"[^{}]*\}", flags=re.IGNORECASE)
_THINKING_TAGS = re.compile(r"<thinking>.*?</thinking>", flags=re.DOTALL | re.IGNORECASE)

_FALLBACK_AUDIT: dict = {
    "score": 0, "critique": "Audit parse error — refinement succeeded.",
    "precision": 0, "alignment": 0, "efficiency": 0,
}


def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _clamp_audit(raw: dict) -> dict:
    def safe_int(val: object, ceiling: int) -> int:
        try:
            return min(max(int(val), 0), ceiling)
        except (TypeError, ValueError):
            return 0
    return {
        "score":      safe_int(raw.get("score"),      100),
        "critique":   _escape_html(str(raw.get("critique", "")).strip()),
        "precision":  safe_int(raw.get("precision"),   40),
        "alignment":  safe_int(raw.get("alignment"),   40),
        "efficiency": safe_int(raw.get("efficiency"),  20),
    }


def _strip_thinking(text: str) -> str:
    return _THINKING_TAGS.sub("", text).strip()


def _parse_output(raw: str) -> Tuple[Optional[str], Optional[dict]]:
    cleaned    = _FENCE_CLEANUP.sub("", raw).strip()
    cleaned    = _strip_thinking(cleaned)
    json_match = _JSON_HUNTER.search(cleaned)
    if not json_match:
        return None, None
    refined_raw = cleaned[: json_match.start()].strip()
    refined     = _TAG_CLEANUP.sub("", refined_raw).strip()
    if not refined:
        return None, None
    try:
        audit = _clamp_audit(json.loads(json_match.group(0)))
    except Exception:
        audit = dict(_FALLBACK_AUDIT)
        audit["critique"] = "Refinement succeeded. Audit JSON malformed."
    return refined, audit


def _build_brand_block(brand_identity: Optional[dict]) -> str:
    if not brand_identity:
        return ""
    lines = ["BRAND CONTEXT (apply to all output):"]
    for key, label in [
        ("name",     "Brand   "),
        ("voice",    "Voice   "),
        ("audience", "Audience"),
        ("values",   "Values  "),
        ("avoid",    "Avoid   "),
        ("examples", "Examples"),
    ]:
        if brand_identity.get(key):
            lines.append(f"  {label}: {brand_identity[key]}")
    lines.append("Every word in the refined prompt must be consistent with this brand identity.")
    return "\n".join(lines)


def _build_system_prompt(
    target:           str,
    framework:        str,
    cognitive:        str,
    islamic:          bool,
    aesthetic_choice: str,
    persona:          Optional[dict] = None,
    retry_critique:   Optional[str]  = None,
    brand_identity:   Optional[dict] = None,
) -> str:
    style        = (
        f"STYLE DIRECTION: {AESTHETIC_PRESETS.get(aesthetic_choice, '')}"
        if aesthetic_choice != "Raw (No Preset)" else ""
    )
    persona_block = inject_persona(persona, target)
    brand_block   = _build_brand_block(brand_identity)
    
    # FIX Bug 4: Visual Director Prompt Injection
    framework_block = f"ACTIVE FRAMEWORK: {framework}"
    if framework == "Visual Director":
        framework_block = f"{framework_block}\n{VISUAL_DIRECTOR_PROMPT}"

    # FIX Bug 5 & 8: Expert Personas & Domain Knowledge Injection
    expert_block = ""
    domain_block = ""
    
    # Wire Expert Personas based on framework
    if framework == "Professional (RACE)":
        expert_block = EXPERT_PROMPT_ENGINEER
    elif framework == "Creative (Chain-of-Thought)":
        expert_block = EXPERT_UX_DESIGNER
    elif framework == "Decision Audit (LUCID)":
        expert_block = EXPERT_DECISION_SCIENCE
    elif "technical" in framework.lower():
        expert_block = EXPERT_CYBERSECURITY
    elif "academic" in framework.lower():
        expert_block = EXPERT_STRATEGIST

    # Wire Domain Knowledge based on cognitive patterns or framework
    if "code" in cognitive.lower() or "technical" in framework.lower():
        domain_block = f"DOMAIN KNOWLEDGE: {DOMAIN_KNOWLEDGE['code_analysis']}"
    elif "marketing" in framework.lower() or "commercial" in cognitive.lower():
        domain_block = f"DOMAIN KNOWLEDGE: {DOMAIN_KNOWLEDGE['marketing']}"
    elif "agent" in cognitive.lower():
        domain_block = f"DOMAIN KNOWLEDGE: {DOMAIN_KNOWLEDGE['agentic_automation']}"
    elif "data" in cognitive.lower():
        domain_block = f"DOMAIN KNOWLEDGE: {DOMAIN_KNOWLEDGE['data_analysis']}"
    elif "text" in cognitive.lower() or "copy" in cognitive.lower():
        domain_block = f"DOMAIN KNOWLEDGE: {DOMAIN_KNOWLEDGE['text_copy']}"

    retry_block   = (
        f"CORRECTION REQUIRED:\n"
        f"Previous attempt scored below quality threshold.\n"
        f"Auditor critique: '{retry_critique}'\n"
        f"Correct this specific issue."
    ) if retry_critique else ""

    parts = [
        CIPHER_IDENTITY,
        CIPHER_REASONING_LAYER,
        expert_block,
        persona_block,
        brand_block,
        domain_block,
        framework_block,
        f"TARGET AI DIALECT: {target}",
        f"DIALECT SYNTAX GUIDE: {TARGET_GUIDES.get(target, '')}",
        style,
        cognitive,
        ISLAMIC_CONTEXT_LAYER if islamic else "",
        retry_block,
        "",
        "MANDATORY AUDIT RUBRIC:",
        "1. PRECISION (40pts): Exact native syntax of target AI.",
        "2. ALIGNMENT (40pts): Every element of user intent preserved.",
        "3. EFFICIENCY (20pts): Every word earns its place.",
        "",
        "OUTPUT FORMAT:",
        "Write the refined prompt first. Then on a new line output the audit JSON.",
        '{"score": <0-100>, "critique": "<one precise sentence>", "precision": <0-40>, "alignment": <0-40>, "efficiency": <0-20>}',
    ]
    return "\n".join(filter(None, parts))


def _call_cipher(
    system_prompt: str,
    user_text:     str,
) -> Tuple[Optional[str], Optional[dict], Optional[str]]:
    try:
        completion = client.chat.completions.create(
            model=MODEL_ID,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": f"[[INPUT_START]]\n{user_text}\n[[INPUT_END]]"},
            ],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS,
        )
        raw = completion.choices[0].message.content
    except Exception as e:
        return None, None, str(e)

    refined, audit = _parse_output(raw)
    if refined is None:
        return None, None, f"Parse failed. Raw:\n{raw[:300]}"
    return refined, audit, None


def detect_best_target(user_text: str) -> tuple:
    system_prompt = f"""You are CIPHER's target classification module.
{TARGET_SELECTION_GUIDE}
Output ONLY valid JSON: {{"target": "<target>", "reason": "<reason>"}}
"""
    try:
        completion = client.chat.completions.create(
            model=MODEL_ID,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_text[:500]},
            ],
            response_format={"type": "json_object"},
            temperature=0.1,
            max_tokens=100,
        )
        raw = json.loads(completion.choices[0].message.content)
        target = str(raw.get("target", "Claude")).strip()
        reason = str(raw.get("reason", "")).strip()
        if target not in TARGET_GUIDES:
            target = "Claude"
        return target, reason
    except Exception as e:
        return "Claude", f"Auto-selection failed ({str(e)[:60]})."


def run_refinement_and_audit(
    user_text:        str,
    target:           str,
    framework:        str,
    lang:             str,
    aesthetic_choice: str,
    islamic_mode:     bool           = False,
    persona:          Optional[dict] = None,
    brand_identity:   Optional[dict] = None,
) -> Tuple[str, dict, Optional[dict]]:
    detected: Optional[dict] = None
    cognitive: str = ""
    if lang == "Arabic (العربية)":
        detected = detect_arabic_pattern(user_text)
        if detected:
            cognitive = (
                f"ARABIC RHETORICAL ARCHITECTURE DETECTED:\n"
                f"  Pattern: {detected['pattern']}\n"
                f"  Paradigm: {detected['prompt_paradigm']}\n"
            )
        else:
            cognitive = "INPUT LANGUAGE: Arabic. Map conceptually, do not translate literally."

    sys_prompt = _build_system_prompt(
        target, framework, cognitive,
        islamic_mode, aesthetic_choice, persona,
        retry_critique=None,
        brand_identity=brand_identity,
    )
    refined, audit, error = _call_cipher(sys_prompt, user_text)
    if error:
        return f"[CIPHER ERROR]: {error}", dict(_FALLBACK_AUDIT), None

    score = audit.get("score", 0) if audit else 0
    if score < RETRY_THRESHOLD and audit and audit.get("critique"):
        retry_prompt = _build_system_prompt(
            target, framework, cognitive,
            islamic_mode, aesthetic_choice, persona,
            retry_critique=audit["critique"],
            brand_identity=brand_identity,
        )
        refined_v2, audit_v2, error_v2 = _call_cipher(retry_prompt, user_text)
        if not error_v2 and refined_v2 and audit_v2:
            if audit_v2.get("score", 0) >= score:
                return refined_v2, audit_v2, detected
    return refined, audit, detected